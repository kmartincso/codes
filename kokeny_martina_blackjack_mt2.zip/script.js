let jatekosPakli = [];
let osztoPakli = [];
let vagyon;
let deck;
function init() {  
    //kartyak generalasa
    var pakli = ['1', '2', '3', '4']
    var szinek = ['kör','káró','pikk','treff']
    var szamok = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]
    deck = new Array();
    for (var j = 0 ; j < pakli.length; j++) {
        for (var i = 0 ; i < szamok.length; i++)
        {
            for(var x = 0; x < szinek.length; x++)
            {
                var weight;
                if (szamok[i] == "J" || szamok[i] == "Q" || szamok[i] == "K"){
                    weight = 10;
                }
                else if (szamok[i] == "A"){
                    weight = 11;
                }
                else {
                    weight = parseInt(szamok[i]);
                }

                var card = { "Value": szamok[i], "Suit": szinek[x], "Weight": weight };
                deck.push(card);
            }
        } 
    }
    deck = shuffle(deck);
 }

window.addEventListener('load', function(){
   init();
});

function jatek() {
    jatekosPakli.push(deck.pop());
    osztoPakli.push(deck.pop());
    jatekosPakli.push(deck.pop());
    osztoPakli.push(deck.pop());
    renderCards();
    if(sumPakliErtek(jatekosPakli) == 21 && sumPakliErtek(osztoPakli) == 21){
        alert("Döntetlen!")
    }
    else if(sumPakliErtek(jatekosPakli) == 21){
        alert("Játékos nyert!")
    }
    else if(sumPakliErtek(osztoPakli) == 21){
        alert("Osztó nyert!")
    }
}

function shuffle(a) {
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}

function makeUL(arrayOfCards) {
    // Listaelem létrehozása:
    var list = document.createElement('ul');

    for (var i = 0; i < arrayOfCards.length; i++) {
        
        var item = document.createElement('li');

        // Item tartalma:
        item.appendChild(document.createTextNode(arrayOfCards[i].Suit + " " + arrayOfCards[i].Value));

        // Tegye be a listába:
        list.appendChild(item);
    }

    // Lista hívása:
    return list;
}

function sumPakliErtek(pakli){
    sum = 0;
    for (let i = 0; i < pakli.length; i++) {
        sum = sum + pakli[i].Weight;
    }
    return sum;
}
function renderCards() {
    var jatekosPakliDomElement = document.getElementById("jatekosPakli");  
    var osztoPakliDomElement = document.getElementById("osztoPakli");  
    if(jatekosPakliDomElement.hasChildNodes()){
        jatekosPakliDomElement.removeChild(jatekosPakliDomElement.childNodes[0]);
    }
    if(osztoPakliDomElement.hasChildNodes()){
        osztoPakliDomElement.removeChild(osztoPakliDomElement.childNodes[0]); 
    }
    jatekosPakliDomElement.appendChild(makeUL(jatekosPakli));
    osztoPakliDomElement.appendChild(makeUL(osztoPakli))
}

function ossz(){
    jatekosPakli.push(deck.pop());
    console.log(jatekosPakli);
    console.log(sumPakliErtek(jatekosPakli))
    renderCards();
    if(sumPakliErtek(jatekosPakli) == 21){
        alert(sumPakliErtek(jatekosPakli) + "Játékos nyert!")
    }
    else if(sumPakliErtek(jatekosPakli) > 21){
        alert(sumPakliErtek(jatekosPakli)  + "Osztó nyert!")
    }
    shuffle();// itt azt szerettem volna, hogyha az osztó nyer, új lap jöjjön
}

function megall(){
    osztoPakli.push(deck.pop());
    renderCards();
    if(sumPakliErtek(jatekosPakli) == 21 && sumPakliErtek(osztoPakli) == 21){
        alert("Döntetlen!")
    }
    else if(sumPakliErtek(jatekosPakli) == 21){
        alert("Játekos nyert!") 
    }
    else if(sumPakliErtek(osztoPakli) == 21){
        alert("Osztó nyert!");
    }
    shuffle(); // itt is azt szerettem volna, hogyha az osztó nyer, új lap jöjjön :( 
}
//


